# Python 3.11 运行时

便携式 Python 3.11.9（Windows x64），含 uv。

- 入口：python.exe
- 安装位置：%LOCALAPPDATA%\OpenPage\runtimes\python-3.11
- 不需要管理员权限，不改 PATH。
